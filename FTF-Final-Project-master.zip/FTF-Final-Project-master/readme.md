# Flask + MongoDB Template

Clone this repository to get started building a Flask app with a MongoDB database.
