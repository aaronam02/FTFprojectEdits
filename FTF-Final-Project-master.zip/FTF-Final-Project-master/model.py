# https://www.w3schools.com/python/trypython.asp?filename=demo_dictionary_nested2

# users["art_Meme"]= {
#     'art1' = {'title': "blm",
#     'picture': 'https://files.slack.com/files-pri/T015TDL95UY-F017MP1S9DZ/whiteboard_2_-01.png'
#     },
#    'art2'= {'title': 'you',
#     'picture' : 'they',
#     },
# }
# users["welcome_display"]= {
#     {'title': 
#     'picture':
#     },
#     {'title': 
#     'picture' :
#     },
#     {'title': 
#     'picture' :
#     },
# }